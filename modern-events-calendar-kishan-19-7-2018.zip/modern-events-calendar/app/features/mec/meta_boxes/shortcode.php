<?php
/** no direct access **/
defined('_MECEXEC_') or die();
?>
<div class="mec-calendar-metabox mec-shortcode">[MEC id="<?php echo $post->ID; ?>"]</div>